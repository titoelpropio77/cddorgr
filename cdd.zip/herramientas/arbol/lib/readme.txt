EventHandler.js and LibCrossBrowser.js are used by the slider component.
i didn't really touch the content or file names, maybe we're going to 
get new versions sometime. --andrej

