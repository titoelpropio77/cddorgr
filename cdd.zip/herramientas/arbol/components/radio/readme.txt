BlueShoes JavaScript Radio Component
====================================

NOTE: 

 - If you use this as standalone package then you may want to 
   change the javascript include path (which currently is 
   /_bsJavascript/components/radio/) to something else. 
   see the examples.

 - For questions etc please go to: 
   http://developer.blueshoes.org/forum/

 - the website for this component is here: 
   http://www.blueshoes.org/en/javascript/radio/


WISHLIST:

